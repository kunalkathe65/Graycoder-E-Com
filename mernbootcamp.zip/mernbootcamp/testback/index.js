const express = require("express");

const app = express();

const PORT = process.env.PORT || 8000;

app.get("/", (req, res) => {
  res.send("Hello World!!");
});

app.get("/signout", (req, res) => {
  res.send("You've been signed out...");
});

app.get("/hitesh", (req, res) => {
  res.send("Hitesh user..");
});

app.listen(PORT, () => {
  console.log(`Server started on port ${PORT}`);
});
