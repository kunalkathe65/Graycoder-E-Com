const User = require("../models/User");

exports.signup = async (req, res) => {
  try {
    const { email } = req.body;
    const isFound = await User.findOne({ email });
    if (isFound) {
      return res.status(400).json({ msg: "User already exists!" });
    } else {
      const user = new User(req.body);
      await user.save((err, user) => {
        if (err) {
          return res.status(400).json({ msg: "Error!" });
        }
        return res.status(200).json({ msg: "User registered!", user });
      });
    }
  } catch (err) {
    return res.status(500).json({ msg: "Server Error!" });
  }
};

exports.signout = (req, res) => {
  res.send("sign out!");
};
