const mongoose = require("mongoose");
const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const cookieParser = require("cookie-parser");
const cors = require("cors");
require("dotenv").config();

const authRoutes = require("./routes/auth");

//DB Connection
mongoose
  .connect(process.env.DB_URL, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useCreateIndex: true,
  })
  .then(() => {
    console.log("DB CONNECTED...");
  })
  .catch((err) => {
    console.log(`ERROR: ${err}`);
  });

//Middlewares
app.use(cors());
app.use(bodyParser.json());
app.use(cookieParser());

//Routes
app.use("/api", authRoutes);

//Starting Server
const PORT = process.env.PORT || 6000;
app.listen(PORT, () => {
  console.log(`Server started at port ${PORT}`);
});
